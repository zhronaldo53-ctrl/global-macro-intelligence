import io
import logging
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, time, timedelta
from time import sleep
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
import plotly.express as px
import requests
import streamlit as st
from urllib3.exceptions import NameResolutionError, ReadTimeoutError

st.set_page_config(page_title='全球宏观与股市观察台', layout='wide')
st.title('📈 全球宏观与股市观察台')
st.caption('显示最近可获得的日收盘价和宏观观测值。抓取时间使用北京时间，缓存命中时保留原抓取时间。')

MARKETS = {'上证综指 (^SSEC)': '^SSEC', '纳斯达克综合指数 (^IXIC)': '^IXIC'}
MACROS = {
    '美国CPI指数': 'CPIAUCSL',
    '美国失业率 (%)': 'UNRATE',
    '美国联邦基金有效利率 (%)': 'DFF',
    '美国10年期国债收益率 (%)': 'DGS10',
    '美国实际GDP（十亿链式2017美元）': 'GDPC1',
    '中国CPI指数 (2015=100)': 'CHNCPIALLMINMEI',
}
BEIJING = ZoneInfo('Asia/Shanghai')
NEW_YORK = ZoneInfo('America/New_York')
FRED_CSV = 'https://fred.stlouisfed.org/graph/fredgraph.csv'
LOGGER = logging.getLogger(__name__)


class DataError(ValueError):
    """A classified request or response failure."""


def request_error(error):
    if isinstance(error, requests.ConnectTimeout):
        return '连接超时'
    if isinstance(error, requests.ReadTimeout):
        return '读取超时'
    if isinstance(error, requests.exceptions.SSLError):
        return 'TLS 错误'
    if isinstance(error, requests.exceptions.ProxyError):
        return '代理连接错误'
    if isinstance(error, requests.ConnectionError):
        pending = [error]
        visited = set()
        while pending:
            cause = pending.pop()
            if id(cause) in visited:
                continue
            visited.add(id(cause))
            if isinstance(cause, NameResolutionError):
                return 'DNS 解析错误'
            if isinstance(cause, ReadTimeoutError):
                return '读取超时'
            pending.extend(item for item in (cause.__cause__, cause.__context__,
                           getattr(cause, 'reason', None), *cause.args)
                           if isinstance(item, BaseException))
        return '连接错误'
    return '请求错误'


def fetch(url, params, label, attempts=1):
    for attempt in range(1, attempts + 1):
        try:
            response = requests.get(url, params=params, timeout=(4, 8), headers={
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'text/csv, application/json, */*',
            })
        except requests.RequestException as error:
            category = request_error(error)
            retryable = category in ('连接超时', '读取超时', 'DNS 解析错误', '连接错误')
            failure = DataError(f'{label} · {category}')
        else:
            status = response.status_code
            LOGGER.info('%s HTTP %s, bytes=%s, content-type=%s', label, status,
                        len(response.content), response.headers.get('Content-Type'))
            if 200 <= status < 300:
                return response
            retryable = status in (408, 500, 502, 503, 504)
            failure = DataError(f'{label} · HTTP {status}')
        LOGGER.warning('%s（第 %s/%s 次）', failure, attempt, attempts)
        if attempt == attempts or not retryable:
            raise failure
        sleep(0.4)


def clean_series(dates, values, label, start, end):
    index = pd.to_datetime(dates, errors='coerce')
    numbers = pd.to_numeric(values, errors='coerce')
    series = pd.Series(np.asarray(numbers, dtype=float), index=pd.DatetimeIndex(index, name=None).rename(None), name=label)
    series = series.loc[series.index.notna()].dropna()
    series = series.loc[~series.index.duplicated(keep='last')].sort_index().loc[start:end]
    if series.empty:
        raise DataError(f'{label} · 无有效观测值')
    return series


@st.cache_data(ttl=3600, max_entries=100, show_spinner=False)
def fred(series, start, end):
    response = fetch(FRED_CSV, {'id': series, 'cosd': start, 'coed': end},
                     f'FRED {series}', attempts=2)
    try:
        frame = pd.read_csv(io.BytesIO(response.content))
        date_column = next((name for name in ('observation_date', 'DATE') if name in frame), None)
        if date_column is None or series not in frame:
            raise ValueError('缺少日期或指标列')
    except (ValueError, UnicodeError) as error:
        raise DataError(f'FRED {series} · 数据解析错误（HTTP {response.status_code}）') from error
    return clean_series(frame[date_column], frame[series], f'FRED {series}', start, end), datetime.now(BEIJING)


@st.cache_data(ttl=1800, max_entries=40, show_spinner=False)
def yahoo(ticker, start, end):
    zone = BEIJING if ticker == '^SSEC' else NEW_YORK
    params = {
        'period1': int(datetime.combine(start, time.min, zone).timestamp()),
        'period2': int(datetime.combine(end + timedelta(days=1), time.min, zone).timestamp()),
        'interval': '1d',
    }
    label = f'Yahoo Finance {ticker}'
    response = fetch(f'https://query1.finance.yahoo.com/v8/finance/chart/{ticker}', params, label)
    try:
        chart = response.json()['chart']
        result = (chart['result'] or [None])[0]
        if result is None:
            raise DataError(f'{label} · 无行情返回')
        meta = result['meta']
        currency = 'CNY' if ticker == '^SSEC' else 'USD'
        if meta['symbol'].upper() != ticker or meta['currency'] != currency:
            raise ValueError('指数代码或货币元数据不符')
        dates = pd.to_datetime(result['timestamp'], unit='s', utc=True).tz_convert(zone).tz_localize(None).normalize()
        close = result['indicators']['quote'][0]['close']
    except DataError:
        raise
    except (ValueError, KeyError, IndexError, TypeError) as error:
        raise DataError(f'{label} · 数据解析错误（HTTP {response.status_code}）') from error
    return clean_series(dates, close, label, start, end), datetime.now(BEIJING)


@st.cache_data(ttl=1800, max_entries=40, show_spinner=False)
def shanghai_sohu(start, end):
    label = '搜狐证券 zs_000001'
    response = fetch('https://q.stock.sohu.com/hisHq', {
        'code': 'zs_000001', 'start': start.strftime('%Y%m%d'),
        'end': end.strftime('%Y%m%d'), 'stat': 1, 'order': 'D', 'period': 'd',
    }, label, attempts=2)
    try:
        result = response.json()[0]
        if result['status'] != 0 or result['code'] != 'zs_000001':
            raise ValueError('指数代码或响应状态不符')
        dates, close = zip(*((row[0], row[2]) for row in result['hq']))
    except (ValueError, KeyError, IndexError, TypeError) as error:
        raise DataError(f'{label} · 数据解析错误（HTTP {response.status_code}）') from error
    return clean_series(dates, close, label, start, end), datetime.now(BEIJING)


@st.cache_data(ttl=1800, max_entries=40, show_spinner=False)
def shanghai_sina(start, end):
    label = '新浪财经 sh000001'
    response = fetch('https://quotes.sina.cn/cn/api/json_v2.php/CN_MarketDataService.getKLineData',
                     {'symbol': 'sh000001', 'scale': 240, 'ma': 'no', 'datalen': 1023}, label)
    try:
        rows = response.json()
        dates, close = zip(*((row['day'], row['close']) for row in rows))
    except (ValueError, KeyError, IndexError, TypeError) as error:
        raise DataError(f'{label} · 数据解析错误（HTTP {response.status_code}）') from error
    return clean_series(dates, close, label, start, end), datetime.now(BEIJING)


@st.cache_data(ttl=120, max_entries=150, show_spinner=False)
def load_series(code, start, end):
    if code == '^SSEC':
        providers = (
            (f'Yahoo Finance {code}', yahoo, (code, start, end)),
            ('搜狐证券 zs_000001', shanghai_sohu, (start, end)),
            ('新浪财经 sh000001', shanghai_sina, (start, end)),
        )
    elif code == '^IXIC':
        providers = (
            (f'Yahoo Finance {code}', yahoo, (code, start, end)),
            ('FRED NASDAQCOM', fred, ('NASDAQCOM', start, end)),
        )
    else:
        providers = ((f'FRED {code}', fred, (code, start, end)),)

    issues = []
    for source, provider, args in providers:
        try:
            values, fetched_at = provider(*args)
        except DataError as error:
            LOGGER.warning('%s', error)
            issues.append(str(error))
        else:
            return values, fetched_at, source, issues
    return None, None, ' → '.join(name for name, _, _ in providers), issues


def clear_data():
    for cached in (fred, yahoo, shanghai_sohu, shanghai_sina, load_series):
        cached.clear()


def last_closed_date(zone, close_time):
    local_now = datetime.now(zone)
    return local_now.date() - timedelta(days=int(local_now.time() < close_time))


with st.sidebar:
    st.header('分析设置')
    years = st.slider('历史区间（年）', 2, 10, 5)
    selected = st.selectbox('目标指数', list(MARKETS))
    st.button('🔄 重新抓取最新数据', on_click=clear_data)
    st.caption('行情缓存 30 分钟，宏观缓存 60 分钟。免费数据可能延迟或修订。')

end = datetime.now(BEIJING).date()
start = end - timedelta(days=round(years * 365.25))
history_start = end - timedelta(days=round(10 * 365.25))
market_ends = {
    '^SSEC': last_closed_date(BEIJING, time(15, 5)),
    '^IXIC': last_closed_date(NEW_YORK, time(16, 5)),
}
prices = {}
macros = {}
details = []
with st.spinner('正在检查行情与宏观数据…'):
    with ThreadPoolExecutor(max_workers=8) as pool:
        jobs = {
            label: pool.submit(load_series, code, history_start, market_ends.get(code, end))
            for label, code in (MARKETS | MACROS).items()
        }
        for label, job in jobs.items():
            values, fetched_at, source, issues = job.result()
            if values is not None:
                if label in MARKETS:
                    recent = values.loc[start:]
                    if not recent.empty:
                        prices[label] = recent
                elif not values.loc[start:].empty:
                    macros[label] = values.loc[start:]
            status = '；'.join(issues) if issues else '正常'
            if values is not None and issues:
                status = f'已使用备用源。{status}'
            details.append({
                '指标': label,
                '最新值': round(float(values.iloc[-1]), 3) if values is not None else None,
                '交易日 / 观测日期': str(values.index[-1].date()) if values is not None else '—',
                '来源': source,
                '抓取时间（北京）': fetched_at.strftime('%Y-%m-%d %H:%M:%S') if fetched_at else '—',
                '状态': status,
            })

st.subheader('一、最新可得市场快照')
for col, label in zip(st.columns(2), MARKETS):
    if label in prices:
        values = prices[label]
        change = (values.iloc[-1] / values.iloc[-2] - 1) * 100 if len(values) > 1 else None
        col.metric(label, f'{values.iloc[-1]:,.2f} 点', f'{change:+.2f}%' if change is not None else None)
    else:
        col.metric(label, '暂无行情')

st.subheader('二、宏观观测值与数据源状态')
st.dataframe(pd.DataFrame(details), width='stretch', hide_index=True)
if not prices:
    st.warning('两只指数均无可用行情。上方仍显示宏观数据和请求状态。')
    st.stop()

st.subheader('三、股市历史走势（各自基期归一化为100）')
normalized = pd.concat({label: s / s.iloc[0] * 100 for label, s in prices.items()}, axis=1)
fig = px.line(normalized.rename_axis('日期').reset_index(), x='日期', y=list(normalized.columns), labels={'value':'归一化指数', 'variable':'市场'})
st.plotly_chart(fig, width='stretch')

st.subheader('四、宏观指标与股市月收益的统计关系')
st.info('采用月末股价计算月收益；宏观变量按月末观测值计算月度变化，并滞后一个月与股市收益配对。此处为探索性相关性，不是因果识别或可直接交易的预测。FRED 历史序列可能经过修订，且本例未按首次公布日构建真实历史信息集。')
if selected not in prices:
    selected = next(iter(prices))
    st.caption(f'所选指数暂缺行情，以下展示 {selected}。')
chosen = prices[selected]
monthly_returns = chosen.resample('ME').last().pct_change(fill_method=None) * 100
monthly_returns = monthly_returns[monthly_returns.index.date < end.replace(day=1)]
records = []
scatter_data = {}
for label, macro in macros.items():
    monthly_macro = macro.resample('ME').last().ffill()
    # CPI, GDP: use percent change; rates/unemployment: percentage point change.
    if label in ('美国CPI指数', '中国CPI指数 (2015=100)', '美国实际GDP（十亿链式2017美元）'):
        change = monthly_macro.pct_change(fill_method=None) * 100
        change_unit = '环比变化 (%)'
    else:
        change = monthly_macro.diff()
        change_unit = '月度变化（百分点/指数单位）'
    paired = pd.concat([change.shift(1).rename('宏观变化'), monthly_returns.rename('指数月收益')], axis=1).dropna()
    if len(paired) >= 12 and paired['宏观变化'].std() > 0 and paired['指数月收益'].std() > 0:
        corr = paired.corr().iloc[0,1]
        records.append({'宏观指标':label, 'Pearson相关系数':round(float(corr), 3), '有效月份':len(paired), '宏观单位':change_unit})
        scatter_data[label] = paired
if records:
    st.dataframe(pd.DataFrame(records).sort_values('Pearson相关系数'), width='stretch', hide_index=True)
    choice = st.selectbox('查看散点关系', list(scatter_data))
    paired = scatter_data[choice].reset_index()
    fig2 = px.scatter(paired, x='宏观变化', y='指数月收益', trendline='ols', hover_data=[paired.columns[0]], title=f'{choice}（滞后1个月） vs {selected}月收益')
    st.plotly_chart(fig2, width='stretch')
else:
    st.warning('有效配对月份不足（至少12个月）或宏观数据暂不可用，无法计算相关系数。')

st.subheader('五、方法与风险')
st.markdown('''- **时间差**：中国股市、美国股市交易时区不同；程序在当地常规收盘时间后五分钟才纳入当日记录，仍取决于来源是否更新。\n- **公布滞后**：CPI、失业率、GDP 的“观测日期”不是数据正式公布日期。简单滞后一个月并不能完全避免未来信息泄露。\n- **频率与可比性**：GDP 为季度数据，月度前向填充仅用于探索；不同国家指标口径也不同。\n- **相关不等于因果**：相关系数受样本期、共同趋势、市场预期及政策反应影响，不能单独作为买卖依据。\n- **中国 CPI**：所用 OECD/FRED 系列是否仍持续更新取决于数据源；缺失时不会虚构数值。''')
